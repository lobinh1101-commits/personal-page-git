# Bài tập SQL - QuanLyDiemThi

## Nội dung
- Tạo cơ sở dữ liệu `QuanLyDiemThi`.
- Tạo các bảng `HocSinh`, `GiaoVien`, `MonHoc`, `BangDiem`.
- Khai báo khóa chính và khóa ngoại theo yêu cầu bài tập.

## Cách chạy
Mở MySQL Workbench, mở file `QuanLyDiemThi.sql`, rồi thực thi các câu lệnh theo thứ tự.

Lưu ý: Nếu cơ sở dữ liệu đã tồn tại, câu lệnh `CREATE DATABASE QuanLyDiemThi;` có thể báo lỗi. Khi chạy lại bài, hãy xóa cơ sở dữ liệu cũ nếu không cần giữ dữ liệu, hoặc thay dòng đầu bằng `CREATE DATABASE IF NOT EXISTS QuanLyDiemThi;`.
